Write down answers to Q1 to Q4 in the report. For Q5 and Q6, write down answers to the questions, in the report.
But the code should be placed in the sub-folder named 'code' inside Q5 or Q6. All the required input data should be placed in the sub-folder
named 'input' inside Q5 or Q6. All sample outputs (if any) should be placed inside the sub-folder named 'output' inside
Q5 or Q6. Your code should prompt the user to specify the path to a folder containing the input data. For this, use the MATLAB command
uigetdir.